class CreateUser < ApplicationRecord
end
