class Integer
  # Integer#hash already implemented for you
end

class Array
  def hash
    return nil.hash if self.empty?

    hash_array = self.map { |ele| ele.to_i.hash}
  end
end
# 0102
# 12

# a = ['hello']
# b = ['hello']

class String
  def hash
  end
end

class Hash
  # This returns 0 because rspec will break if it returns nil
  # Make sure to implement an actual Hash#hash method
  def hash
    0
  end
end


# 100 / 3 == 33.3
# 100 = input
# 33.3 = output

# 'kansfgkjah' -> XOR -> Specific divisor (123456)

# '981513'