class AnswerChoice < ApplicationRecord
end
